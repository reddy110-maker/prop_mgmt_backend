<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import axios from 'axios';
import { 
  Building2, 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  Loader2,
  AlertCircle,
  Home,
  ArrowLeft,
  DollarSign,
  List,
  Pencil,
  Trash2,
  X,
  CheckCircle
} from 'lucide-vue-next';

/**
 * IA 10 Property Management Assignment - Frontend
 * This application connects to a live FastAPI backend.
 * All data is fetched dynamically; no hardcoded sample data is used.
 */

const API_BASE_URL = 'https://prop-mgmt-api-143473825525.us-central1.run.app';

// --- DATA MODELS (TYPES) ---
interface Property {
  property_id: number;
  name: string;
  address: string;
  city: string;
  state: string;
  postal_code: string;
  property_type: string;
  tenant_name: string;
  monthly_rent: number;
}

interface IncomeRecord {
  id: number;
  property_id: number;
  amount: number;
  description: string;
  date: string;
}

interface ExpenseRecord {
  id: number;
  property_id: number;
  amount: number;
  category: string;
  description: string;
  date: string;
}

interface ExpenseCategory {
  category: string;
  total_amount: number;
}

interface FinancialSummary {
  total_income: number;
  total_expenses: number;
  net_income: number;
}

// --- STATE MANAGEMENT ---
const properties = ref<Property[]>([]);
const selectedProperty = ref<Property | null>(null);
const incomeRecords = ref<IncomeRecord[]>([]);
const expenseRecords = ref<ExpenseRecord[]>([]);
const totalIncome = ref(0);
const totalExpenses = ref(0);
const expensesByCategory = ref<ExpenseCategory[]>([]);
const summary = ref<FinancialSummary | null>(null);

// Helper for grouping income into cleaner categories
const getIncomeCategory = (description: string): string => {
  if (!description) return 'Other Income';
  const d = description.toLowerCase();
  // Group anything mentioning "rent" or "back payment" into "Rent"
  if (d.includes('rent') || d.includes('back payment')) {
    return 'Rent';
  }
  return description;
};

const incomeByCategory = computed(() => {
  const groups: Record<string, number> = {};
  incomeRecords.value.forEach(record => {
    const category = getIncomeCategory(record.description);
    groups[category] = (groups[category] || 0) + (Number(record.amount) || 0);
  });
  return Object.entries(groups).map(([description, total]) => ({
    description,
    total
  })).sort((a, b) => b.total - a.total);
});

const isLoading = ref(false);
const globalError = ref<string | null>(null);
const feedback = ref<{ message: string; type: 'success' | 'error' } | null>(null);

// --- FORM STATE ---
const incomeForm = ref({
  amount: 0,
  description: '',
  date: new Date().toISOString().split('T')[0]
});

const expenseForm = ref({
  amount: 0,
  category: '',
  description: '',
  date: new Date().toISOString().split('T')[0]
});

const editingProperty = ref<Property | null>(null);
const editForm = ref({
  name: '',
  address: '',
  city: '',
  state: '',
  postal_code: '',
  property_type: '',
  tenant_name: '',
  monthly_rent: 0
});

const isAddingProperty = ref(false);
const addPropertyForm = ref({
  name: '',
  address: '',
  city: '',
  state: '',
  postal_code: '',
  property_type: '',
  tenant_name: '',
  monthly_rent: 0
});

// --- API METHODS ---

// Fetch all properties for the list view
const fetchProperties = async () => {
  isLoading.value = true;
  globalError.value = null;
  try {
    const response = await axios.get(`${API_BASE_URL}/properties`);
    properties.value = response.data;
  } catch (err) {
    globalError.value = 'Could not connect to the Property API. Please check your connection.';
    console.error(err);
  } finally {
    isLoading.value = false;
  }
};

// Fetch all data related to a single property
const fetchPropertyDetails = async (propertyId: number) => {
  isLoading.value = true;
  try {
    // We use Promise.all to fetch all data points simultaneously for better performance
    const [
      propRes,
      incomeRes,
      expenseRes,
      totalIncomeRes,
      totalExpenseRes,
      categoryRes,
      summaryRes
    ] = await Promise.all([
      axios.get(`${API_BASE_URL}/properties/${propertyId}`),
      axios.get(`${API_BASE_URL}/income/${propertyId}`),
      axios.get(`${API_BASE_URL}/expenses/${propertyId}`),
      axios.get(`${API_BASE_URL}/properties/${propertyId}/income/total`),
      axios.get(`${API_BASE_URL}/properties/${propertyId}/expenses/total`),
      axios.get(`${API_BASE_URL}/expenses/${propertyId}/by-category`),
      axios.get(`${API_BASE_URL}/properties/${propertyId}/summary`)
    ]);

    selectedProperty.value = propRes.data;
    incomeRecords.value = incomeRes.data;
    expenseRecords.value = expenseRes.data;
    totalIncome.value = Number(totalIncomeRes.data.total_income) || 0;
    totalExpenses.value = Number(totalExpenseRes.data.total_expenses) || 0;
    // Extract the array from the response object
    expensesByCategory.value = categoryRes.data.expense_categories || [];
    summary.value = summaryRes.data;
  } catch (err) {
    showFeedback('Error refreshing property data.', 'error');
    console.error(err);
  } finally {
    isLoading.value = false;
  }
};

const handleSelectProperty = (propertyId: number) => {
  fetchPropertyDetails(propertyId);
  // Smooth scroll to dashboard after a short delay to allow DOM update
  setTimeout(() => {
    const el = document.getElementById('dashboard-section');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 100);
};

const handleGoBack = () => {
  selectedProperty.value = null;
  incomeRecords.value = [];
  expenseRecords.value = [];
  summary.value = null;
  // Scroll back to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

// POST new income record
const submitIncome = async () => {
  if (!selectedProperty.value) return;
  const propertyId = selectedProperty.value.property_id;
  try {
    // Removing property_id from body as it is already in the URL path
    // This is a common cause of 422 errors in FastAPI if the schema doesn't expect it
    await axios.post(`${API_BASE_URL}/income/${propertyId}`, {
      amount: incomeForm.value.amount,
      description: incomeForm.value.description,
      date: incomeForm.value.date
    });
    showFeedback('Income record saved successfully!', 'success');
    incomeForm.value = { amount: 0, description: '', date: new Date().toISOString().split('T')[0] };
    fetchPropertyDetails(propertyId);
  } catch (err: any) {
    console.error('Income Error:', err.response?.data);
    const detail = err.response?.data?.detail;
    let msg = 'Failed to save income.';
    if (Array.isArray(detail)) {
      // Format FastAPI validation errors: "field: message"
      msg = detail.map((d: any) => `${d.loc[d.loc.length - 1]}: ${d.msg}`).join(', ');
    } else if (typeof detail === 'string') {
      msg = detail;
    }
    showFeedback(msg, 'error');
  }
};

// POST new expense record
const submitExpense = async () => {
  if (!selectedProperty.value) return;
  const propertyId = selectedProperty.value.property_id;
  try {
    await axios.post(`${API_BASE_URL}/expenses/${propertyId}`, {
      amount: expenseForm.value.amount,
      category: expenseForm.value.category,
      description: expenseForm.value.description,
      date: expenseForm.value.date
    });
    showFeedback('Expense record saved successfully!', 'success');
    expenseForm.value = { amount: 0, category: '', description: '', date: new Date().toISOString().split('T')[0] };
    fetchPropertyDetails(propertyId);
  } catch (err: any) {
    console.error('Expense Error:', err.response?.data);
    const detail = err.response?.data?.detail;
    let msg = 'Failed to save expense.';
    if (Array.isArray(detail)) {
      msg = detail.map((d: any) => `${d.loc[d.loc.length - 1]}: ${d.msg}`).join(', ');
    } else if (typeof detail === 'string') {
      msg = detail;
    }
    showFeedback(msg, 'error');
  }
};

// DELETE property logic
const showDeleteConfirm = ref(false);
const propertyToDelete = ref<number | null>(null);

const deleteProperty = (propertyId: number) => {
  propertyToDelete.value = propertyId;
  showDeleteConfirm.value = true;
};

const cancelDelete = () => {
  showDeleteConfirm.value = false;
  propertyToDelete.value = null;
};

const confirmDelete = async () => {
  if (propertyToDelete.value === null) return;
  
  const propertyId = propertyToDelete.value;
  isLoading.value = true;
  try {
    await axios.delete(`${API_BASE_URL}/properties/${propertyId}`);
    showFeedback('Property deleted successfully.', 'success');
    
    // If the deleted property is currently selected, clear it
    if (selectedProperty.value?.property_id === propertyId) {
      selectedProperty.value = null;
    }
    
    // Refresh the list
    fetchProperties();
  } catch (err: any) {
    console.error('Delete Error:', err.response?.data || err);
    showFeedback('Failed to delete property.', 'error');
  } finally {
    isLoading.value = false;
    showDeleteConfirm.value = false;
    propertyToDelete.value = null;
  }
};

// EDIT property logic
const startEdit = (property: Property) => {
  editingProperty.value = property;
  editForm.value = {
    name: property.name || '',
    address: property.address || '',
    city: property.city || '',
    state: property.state || '',
    postal_code: property.postal_code || '',
    property_type: property.property_type || '',
    tenant_name: property.tenant_name || '',
    monthly_rent: property.monthly_rent || 0
  };
  // Scroll to top to see the edit form
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

const cancelEdit = () => {
  editingProperty.value = null;
};

const submitEdit = async () => {
  if (!editingProperty.value) return;
  
  isLoading.value = true;
  try {
    await axios.put(`${API_BASE_URL}/properties/${editingProperty.value.property_id}`, editForm.value);
    showFeedback('Property updated successfully.', 'success');
    editingProperty.value = null;
    
    // If the edited property is currently selected, refresh its details
    if (selectedProperty.value?.property_id === editingProperty.value?.property_id) {
      fetchPropertyDetails(selectedProperty.value.property_id);
    }
    
    fetchProperties();
  } catch (err: any) {
    console.error('Update Error:', err.response?.data);
    const detail = err.response?.data?.detail;
    let msg = 'Failed to update property.';
    if (Array.isArray(detail)) {
      msg = detail.map((d: any) => `${d.loc[d.loc.length - 1]}: ${d.msg}`).join(', ');
    } else if (typeof detail === 'string') {
      msg = detail;
    }
    showFeedback(msg, 'error');
  } finally {
    isLoading.value = false;
  }
};

// ADD property logic
const startAddProperty = () => {
  isAddingProperty.value = true;
  addPropertyForm.value = {
    name: '',
    address: '',
    city: '',
    state: '',
    postal_code: '',
    property_type: '',
    tenant_name: '',
    monthly_rent: 0
  };
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

const cancelAddProperty = () => {
  isAddingProperty.value = false;
};

const submitAddProperty = async () => {
  isLoading.value = true;
  try {
    await axios.post(`${API_BASE_URL}/properties`, addPropertyForm.value);
    showFeedback('Property added successfully.', 'success');
    isAddingProperty.value = false;
    fetchProperties();
  } catch (err: any) {
    console.error('Add Property Error:', err.response?.data);
    const detail = err.response?.data?.detail;
    let msg = 'Failed to add property.';
    if (Array.isArray(detail)) {
      msg = detail.map((d: any) => `${d.loc[d.loc.length - 1]}: ${d.msg}`).join(', ');
    } else if (typeof detail === 'string') {
      msg = detail;
    }
    showFeedback(msg, 'error');
  } finally {
    isLoading.value = false;
  }
};

// Helper for showing temporary messages
const showFeedback = (message: string, type: 'success' | 'error') => {
  feedback.value = { message, type };
  setTimeout(() => feedback.value = null, 4000);
};

// Helper for formatting money
const toCurrency = (num: number) => {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(num);
};

// Initial load
onMounted(fetchProperties);
</script>

<template>
  <div class="min-h-screen bg-gray-50 text-gray-900 p-4 md:p-10 font-sans">
    <div class="max-w-5xl mx-auto">
      
      <!-- HEADER -->
      <header class="mb-12 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 class="text-5xl font-black text-gray-900 flex items-center gap-4 tracking-tight">
            <Building2 class="text-gold w-12 h-12" />
            Property Dashboard
          </h1>
          <p class="text-gray-500 mt-2 font-medium text-lg">Manage your real estate portfolio with precision.</p>
        </div>
        <div class="flex items-center gap-3">
          <div class="bg-white px-6 py-3 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-3">
            <div class="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            <span class="text-sm font-black text-gray-900 uppercase tracking-widest">System Online</span>
          </div>
        </div>
      </header>

      <!-- EDIT PROPERTY FORM -->
      <section v-if="editingProperty" class="mb-16 animate-in fade-in slide-in-from-top-8 duration-500">
        <div class="bg-white p-10 rounded-[3rem] border-4 border-gold shadow-2xl relative overflow-hidden">
          <div class="absolute top-0 left-0 w-full h-2 bg-gold"></div>
          <div class="flex justify-between items-center mb-10">
            <div class="flex items-center gap-4">
              <div class="p-3 bg-gold text-black rounded-2xl shadow-lg shadow-gold/20">
                <Pencil class="w-8 h-8" />
              </div>
              <div>
                <h2 class="text-3xl font-black text-gray-900 tracking-tight">
                  Edit Property
                </h2>
                <p class="text-gray-500 font-bold">{{ editingProperty.name }}</p>
              </div>
            </div>
            <button @click="cancelEdit" class="p-3 hover:bg-gray-100 rounded-2xl transition-all text-gray-400 hover:text-black active:scale-95">
              <X class="w-8 h-8" />
            </button>
          </div>
          
          <form @submit.prevent="submitEdit" class="space-y-10">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Property Name</label>
                <input v-model="editForm.name" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all text-lg" />
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Address</label>
                <input v-model="editForm.address" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all text-lg" />
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">City</label>
                <input v-model="editForm.city" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">State</label>
                <input v-model="editForm.state" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Postal Code</label>
                <input v-model="editForm.postal_code" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Property Type</label>
                <select v-model="editForm.property_type" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all appearance-none">
                  <option value="" disabled>Select Type</option>
                  <option value="Single Family">Single Family</option>
                  <option value="Multi Family">Multi Family</option>
                  <option value="Commercial">Commercial</option>
                  <option value="Industrial">Industrial</option>
                </select>
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Tenant Name</label>
                <input v-model="editForm.tenant_name" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Monthly Rent</label>
                <div class="relative">
                  <DollarSign class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input v-model.number="editForm.monthly_rent" type="number" required class="w-full pl-12 pr-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all text-xl" />
                </div>
              </div>
            </div>

            <div class="flex gap-6 pt-6">
              <button type="submit" class="flex-1 py-5 bg-black text-gold font-black rounded-3xl hover:bg-gray-900 transition-all shadow-2xl shadow-black/30 active:scale-[0.98] text-lg">
                Update Property Details
              </button>
              <button type="button" @click="cancelEdit" class="px-12 py-5 bg-gray-100 text-gray-600 font-black rounded-3xl hover:bg-gray-200 transition-all active:scale-[0.98]">
                Cancel
              </button>
            </div>
          </form>
        </div>
      </section>

      <!-- ADD PROPERTY FORM -->
      <section v-if="isAddingProperty" class="mb-16 animate-in fade-in slide-in-from-top-8 duration-500">
        <div class="bg-white p-10 rounded-[3rem] border-4 border-black shadow-2xl relative overflow-hidden">
          <div class="absolute top-0 left-0 w-full h-2 bg-black"></div>
          <div class="flex justify-between items-center mb-10">
            <div class="flex items-center gap-4">
              <div class="p-3 bg-black text-gold rounded-2xl shadow-lg shadow-black/20">
                <Plus class="w-8 h-8" />
              </div>
              <div>
                <h2 class="text-3xl font-black text-gray-900 tracking-tight">
                  Add New Property
                </h2>
                <p class="text-gray-500 font-bold text-sm uppercase tracking-widest">Expand your portfolio</p>
              </div>
            </div>
            <button @click="cancelAddProperty" class="p-3 hover:bg-gray-100 rounded-2xl transition-all text-gray-400 hover:text-black active:scale-95">
              <X class="w-8 h-8" />
            </button>
          </div>
          
          <form @submit.prevent="submitAddProperty" class="space-y-10">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Property Name</label>
                <input v-model="addPropertyForm.name" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all text-lg" />
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Address</label>
                <input v-model="addPropertyForm.address" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all text-lg" />
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">City</label>
                <input v-model="addPropertyForm.city" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">State</label>
                <input v-model="addPropertyForm.state" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Postal Code</label>
                <input v-model="addPropertyForm.postal_code" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Property Type</label>
                <select v-model="addPropertyForm.property_type" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all appearance-none">
                  <option value="" disabled>Select Type</option>
                  <option value="Single Family">Single Family</option>
                  <option value="Multi Family">Multi Family</option>
                  <option value="Commercial">Commercial</option>
                  <option value="Industrial">Industrial</option>
                </select>
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Tenant Name</label>
                <input v-model="addPropertyForm.tenant_name" type="text" required class="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Monthly Rent</label>
                <div class="relative">
                  <DollarSign class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input v-model.number="addPropertyForm.monthly_rent" type="number" required class="w-full pl-12 pr-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all text-xl" />
                </div>
              </div>
            </div>

            <div class="flex gap-6 pt-6">
              <button type="submit" class="flex-1 py-5 bg-gold text-black font-black rounded-3xl hover:bg-[#BFA981] transition-all shadow-2xl shadow-gold/30 active:scale-[0.98] text-lg">
                Add Property to Portfolio
              </button>
              <button type="button" @click="cancelAddProperty" class="px-12 py-5 bg-gray-100 text-gray-600 font-black rounded-3xl hover:bg-gray-200 transition-all active:scale-[0.98]">
                Cancel
              </button>
            </div>
          </form>
        </div>
      </section>

      <!-- FEEDBACK NOTIFICATIONS -->
      <div v-if="feedback" :class="[
        'fixed bottom-10 right-10 z-[200] px-8 py-5 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.2)] flex items-center gap-4 animate-in slide-in-from-right-10 duration-500 border-2',
        feedback.type === 'success' ? 'bg-white border-gold text-black' : 'bg-black border-red-500 text-white'
      ]">
        <div :class="[
          'p-2 rounded-xl',
          feedback.type === 'success' ? 'bg-gold/10 text-gold' : 'bg-red-500/10 text-red-500'
        ]">
          <CheckCircle v-if="feedback.type === 'success'" class="w-6 h-6" />
          <AlertCircle v-else class="w-6 h-6" />
        </div>
        <div>
          <p class="text-[10px] font-black uppercase tracking-[0.2em] opacity-50">{{ feedback.type === 'success' ? 'Success' : 'Error' }}</p>
          <p class="font-black tracking-tight">{{ feedback.message }}</p>
        </div>
      </div>

      <!-- DELETE CONFIRMATION MODAL -->
      <div v-if="showDeleteConfirm" class="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
        <div class="bg-white w-full max-w-md p-10 rounded-[3rem] shadow-[0_0_100px_rgba(0,0,0,0.3)] border-4 border-black animate-in zoom-in-95 duration-300 relative overflow-hidden">
          <div class="absolute top-0 left-0 w-full h-2 bg-red-500"></div>
          <div class="flex items-center gap-5 mb-8">
            <div class="p-4 bg-red-50 text-red-500 rounded-2xl shadow-inner">
              <Trash2 class="w-10 h-10" />
            </div>
            <div>
              <h3 class="text-2xl font-black text-gray-900 tracking-tight">Delete Property?</h3>
              <p class="text-red-500 font-black text-[10px] uppercase tracking-[0.2em]">Permanent Action</p>
            </div>
          </div>
          
          <p class="text-gray-600 mb-10 font-bold leading-relaxed text-lg">
            Are you sure you want to delete this property? This will remove all associated income and expense records.
          </p>
          
          <div class="flex flex-col gap-3">
            <button 
              @click="confirmDelete" 
              class="w-full py-5 bg-red-500 text-white font-black rounded-2xl hover:bg-red-600 transition-all shadow-2xl shadow-red-500/30 flex items-center justify-center gap-3 active:scale-[0.98] text-lg"
              :disabled="isLoading"
            >
              <Loader2 v-if="isLoading" class="w-6 h-6 animate-spin" />
              <span v-else>Yes, Delete Property</span>
            </button>
            <button 
              @click="cancelDelete" 
              class="w-full py-5 bg-gray-100 text-gray-600 font-black rounded-2xl hover:bg-gray-200 transition-all active:scale-[0.98]"
              :disabled="isLoading"
            >
              Keep Property
            </button>
          </div>
        </div>
      </div>

      <!-- GLOBAL ERROR STATE -->
      <div v-if="globalError" class="bg-gray-100 border-2 border-gray-200 p-8 rounded-3xl text-gray-900 text-center mb-10">
        <AlertCircle class="w-12 h-12 mx-auto mb-4 text-gold" />
        <h2 class="text-xl font-bold mb-2">Connection Error</h2>
        <p class="mb-6">{{ globalError }}</p>
        <button @click="fetchProperties" class="px-8 py-3 bg-black text-gold rounded-xl font-bold hover:bg-gray-900 transition-all">
          Try Again
        </button>
      </div>

      <!-- PROPERTY LIST VIEW (Always visible) -->
      <section class="mb-16">
        <div class="flex items-center justify-between mb-8">
          <div class="flex items-center gap-3">
            <div class="p-2 bg-gold/10 rounded-xl">
              <Home class="text-gold w-6 h-6" />
            </div>
            <h2 class="text-3xl font-black text-gray-900 tracking-tight">
              Available Properties
            </h2>
          </div>
          <div class="flex items-center gap-4">
            <span v-if="properties.length > 0" class="bg-gold/10 text-gold px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest border border-gold/20">
              {{ properties.length }} Properties
            </span>
            <button 
              @click="startAddProperty" 
              class="flex items-center gap-2 px-6 py-3 bg-black text-gold rounded-2xl font-black text-sm hover:bg-gray-900 transition-all shadow-xl shadow-black/20 active:scale-95"
            >
              <Plus class="w-5 h-5" />
              Add Property
            </button>
          </div>
        </div>

        <div v-if="isLoading && properties.length === 0" class="text-center py-20 bg-white rounded-3xl border border-gray-100 shadow-sm">
          <Loader2 class="w-12 h-12 text-gold animate-spin mx-auto mb-4" />
          <p class="text-gray-500 font-black uppercase tracking-widest text-xs">Loading your portfolio...</p>
        </div>

        <div v-else-if="properties.length === 0" class="bg-white border-2 border-dashed border-gray-200 p-20 rounded-[3rem] text-center">
          <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <Home class="w-10 h-10 text-gray-300" />
          </div>
          <h3 class="text-2xl font-black text-gray-900 mb-2">No properties yet</h3>
          <p class="text-gray-500 mb-8 font-medium">Add your first property to get started with your dashboard.</p>
          <button 
            @click="startAddProperty" 
            class="px-8 py-4 bg-gold text-black rounded-2xl font-black hover:bg-[#BFA981] transition-all shadow-lg shadow-gold/20"
          >
            Add First Property
          </button>
        </div>

        <div v-else class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div 
            v-for="prop in properties" 
            :key="prop.property_id"
            @click="handleSelectProperty(prop.property_id)"
            :class="[
              'bg-white p-8 rounded-[2.5rem] border transition-all cursor-pointer group relative overflow-hidden flex flex-col',
              selectedProperty?.property_id === prop.property_id 
                ? 'border-gold ring-8 ring-gold/5 shadow-2xl -translate-y-2' 
                : 'border-gray-100 shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-2'
            ]"
          >
            <div v-if="selectedProperty?.property_id === prop.property_id" class="absolute top-0 right-0 bg-gold text-black px-4 py-2 rounded-bl-2xl text-[10px] font-black uppercase tracking-[0.2em]">
              Active
            </div>
            
            <div class="flex items-start justify-between mb-6">
              <div :class="[
                'p-4 rounded-2xl transition-all duration-500',
                selectedProperty?.property_id === prop.property_id ? 'bg-gold text-black' : 'bg-gray-50 text-gold group-hover:bg-gold group-hover:text-black'
              ]">
                <Home class="w-7 h-7" />
              </div>
              <div class="flex flex-col items-end">
                <span class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Type</span>
                <span class="bg-gray-100 px-3 py-1 rounded-full text-[10px] font-black text-gray-600 uppercase tracking-widest">
                  {{ prop.property_type || 'Residential' }}
                </span>
              </div>
            </div>

            <div class="flex-1">
              <h3 class="text-2xl font-black text-gray-900 mb-2 tracking-tight group-hover:text-gold transition-colors">{{ prop.name }}</h3>
              <div class="flex items-center gap-2 text-gray-500 mb-6">
                <List class="w-4 h-4 text-gray-300" />
                <p class="text-sm font-bold truncate">{{ prop.address }}</p>
              </div>
            </div>
            
            <div class="grid grid-cols-2 gap-3 pt-6 border-t border-gray-50">
              <button 
                @click.stop="startEdit(prop)"
                class="flex items-center justify-center gap-2 py-3 bg-gray-50 text-gray-600 rounded-xl text-xs font-black hover:bg-gold hover:text-black transition-all active:scale-95"
              >
                <Pencil class="w-4 h-4" />
                Edit
              </button>
              <button 
                @click.stop="deleteProperty(prop.property_id)"
                class="flex items-center justify-center gap-2 py-3 bg-gray-50 text-gray-600 rounded-xl text-xs font-black hover:bg-red-500 hover:text-white transition-all active:scale-95"
              >
                <Trash2 class="w-4 h-4" />
                Delete
              </button>
            </div>
          </div>
        </div>
      </section>

      <!-- PROPERTY DASHBOARD (Visible when a property is selected) -->
      <div v-if="selectedProperty" id="dashboard-section" class="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        <div class="flex items-center gap-4 mb-2">
          <div class="h-px flex-1 bg-gray-200"></div>
          <h2 class="text-sm font-black text-gray-400 uppercase tracking-[0.2em]">Property Dashboard</h2>
          <div class="h-px flex-1 bg-gray-200"></div>
        </div>

        <!-- PROPERTY INFO & SUMMARY -->
        <div class="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-xl flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 relative overflow-hidden">
          <div class="absolute top-0 left-0 w-2 h-full bg-gold"></div>
          <div>
            <div class="flex items-center gap-4 mb-3">
              <h2 class="text-4xl font-black text-gray-900 tracking-tight">{{ selectedProperty.name }}</h2>
              <button @click="handleGoBack" class="p-3 bg-gray-50 hover:bg-gray-100 rounded-2xl transition-all text-gray-400 hover:text-black active:scale-95" title="Clear Selection">
                <ArrowLeft class="w-6 h-6" />
              </button>
            </div>
            <p class="text-gray-500 flex items-center gap-3 font-bold text-lg">
              <div class="p-2 bg-gold/10 rounded-lg">
                <Home class="w-5 h-5 text-gold" />
              </div>
              {{ selectedProperty.address }}
            </p>
          </div>
          
          <div v-if="summary" class="flex flex-wrap gap-6 w-full lg:w-auto">
            <div class="bg-black px-10 py-6 rounded-3xl shadow-2xl shadow-black/20 flex-1 lg:flex-none text-center border border-white/10">
              <p class="text-[10px] font-black text-gold uppercase tracking-[0.3em] mb-2">Net Income</p>
              <p class="text-4xl font-black text-white tracking-tight">{{ toCurrency(summary.net_income) }}</p>
            </div>
          </div>
        </div>

        <!-- FINANCIAL CARDS -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div class="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-lg hover:shadow-xl transition-shadow group">
            <div class="flex items-center gap-4 mb-8">
              <div class="p-4 bg-gold/10 text-gold rounded-2xl group-hover:scale-110 transition-transform duration-500"><TrendingUp class="w-8 h-8" /></div>
              <h4 class="font-black text-gray-400 uppercase text-xs tracking-[0.2em]">Total Income</h4>
            </div>
            <p class="text-5xl font-black text-gray-900 tracking-tight">{{ toCurrency(totalIncome) }}</p>
          </div>

          <div class="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-lg hover:shadow-xl transition-shadow group">
            <div class="flex items-center gap-4 mb-8">
              <div class="p-4 bg-gray-50 text-black rounded-2xl group-hover:scale-110 transition-transform duration-500"><TrendingDown class="w-8 h-8" /></div>
              <h4 class="font-black text-gray-400 uppercase text-xs tracking-[0.2em]">Total Expenses</h4>
            </div>
            <p class="text-5xl font-black text-gray-900 tracking-tight">{{ toCurrency(totalExpenses) }}</p>
          </div>
        </div>

        <!-- CATEGORY BREAKDOWNS -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- INCOME BY CATEGORY -->
          <div class="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm">
            <div class="flex items-center gap-3 mb-6">
              <div class="p-3 bg-gold/10 text-gold rounded-xl"><List class="w-6 h-6" /></div>
              <h4 class="font-black text-gray-400 uppercase text-xs tracking-widest">Income by Category</h4>
            </div>
            <div class="space-y-3">
              <div v-for="item in incomeByCategory" :key="item.description" class="flex justify-between items-center text-sm">
                <span class="text-gray-500 font-bold">{{ item.description }}</span>
                <span class="font-black text-gray-900">{{ toCurrency(Number(item.total) || 0) }}</span>
              </div>
              <p v-if="incomeByCategory.length === 0" class="text-gray-400 italic text-sm">No income records yet.</p>
            </div>
          </div>

          <!-- EXPENSES BY CATEGORY -->
          <div class="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm">
            <div class="flex items-center gap-3 mb-6">
              <div class="p-3 bg-gray-100 text-black rounded-xl"><List class="w-6 h-6" /></div>
              <h4 class="font-black text-gray-400 uppercase text-xs tracking-widest">Expenses by Category</h4>
            </div>
            <div class="space-y-3">
              <div v-for="item in expensesByCategory" :key="item.category" class="flex justify-between items-center text-sm">
                <span class="text-gray-500 font-bold">{{ item.category }}</span>
                <span class="font-black text-gray-900">{{ toCurrency(Number(item.total_amount) || 0) }}</span>
              </div>
              <p v-if="expensesByCategory.length === 0" class="text-gray-400 italic text-sm">No expenses yet.</p>
            </div>
          </div>
        </div>

        <!-- FORMS -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <!-- INCOME FORM -->
          <div class="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-lg">
            <h3 class="text-2xl font-black mb-8 flex items-center gap-4 tracking-tight">
              <div class="p-2 bg-gold/10 rounded-xl">
                <Plus class="text-gold w-6 h-6" />
              </div>
              Record Income
            </h3>
            <form @submit.prevent="submitIncome" class="space-y-8">
              <div class="grid grid-cols-2 gap-6">
                <div class="space-y-3">
                  <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Amount ($)</label>
                  <div class="relative">
                    <DollarSign class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input v-model.number="incomeForm.amount" type="number" step="0.01" required class="w-full pl-10 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
                  </div>
                </div>
                <div class="space-y-3">
                  <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Date</label>
                  <input v-model="incomeForm.date" type="date" required class="w-full px-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
                </div>
              </div>
              <div class="space-y-3">
                <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Description</label>
                <input v-model="incomeForm.description" type="text" placeholder="e.g. Rent Payment" required class="w-full px-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
              </div>
              <button type="submit" class="w-full py-5 bg-gold text-black font-black rounded-2xl hover:bg-[#BFA981] transition-all shadow-2xl shadow-gold/30 active:scale-[0.98]">
                Save Income Record
              </button>
            </form>
          </div>

          <!-- EXPENSE FORM -->
          <div class="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-lg">
            <h3 class="text-2xl font-black mb-8 flex items-center gap-4 tracking-tight">
              <div class="p-2 bg-gray-50 rounded-xl">
                <Plus class="text-black w-6 h-6" />
              </div>
              Record Expense
            </h3>
            <form @submit.prevent="submitExpense" class="space-y-8">
              <div class="grid grid-cols-2 gap-6">
                <div class="space-y-3">
                  <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Amount ($)</label>
                  <div class="relative">
                    <DollarSign class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input v-model.number="expenseForm.amount" type="number" step="0.01" required class="w-full pl-10 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
                  </div>
                </div>
                <div class="space-y-3">
                  <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Date</label>
                  <input v-model="expenseForm.date" type="date" required class="w-full px-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
                </div>
              </div>
              <div class="grid grid-cols-2 gap-6">
                <div class="space-y-3">
                  <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Category</label>
                  <select v-model="expenseForm.category" required class="w-full px-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all appearance-none">
                    <option value="" disabled>Select...</option>
                    <option value="Mortgage">Mortgage</option>
                    <option value="Maintenance">Maintenance</option>
                    <option value="Utilities">Utilities</option>
                    <option value="Taxes">Taxes</option>
                    <option value="Insurance">Insurance</option>
                    <option value="Management">Management</option>
                    <option value="Repair">Repair</option>
                    <option value="Supplies">Supplies</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div class="space-y-3">
                  <label class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Description</label>
                  <input v-model="expenseForm.description" type="text" placeholder="e.g. Plumbing fix" required class="w-full px-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-gold/10 focus:border-gold outline-none font-bold transition-all" />
                </div>
              </div>
              <button type="submit" class="w-full py-5 bg-black text-gold font-black rounded-2xl hover:bg-gray-900 transition-all shadow-2xl shadow-black/30 active:scale-[0.98]">
                Save Expense Record
              </button>
            </form>
          </div>
        </div>

        <!-- DATA TABLES -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <!-- INCOME TABLE -->
          <div class="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
            <div class="p-10 border-b border-gray-50 flex justify-between items-center bg-gray-50/30">
              <h3 class="text-xl font-black text-gray-900 tracking-tight">Income History</h3>
              <span class="bg-gold text-black px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-gold/20">{{ incomeRecords.length }} records</span>
            </div>
            <div class="overflow-x-auto">
              <table class="w-full text-left">
                <thead class="bg-gray-50/50 text-gray-400 text-[10px] font-black uppercase tracking-[0.2em]">
                  <tr>
                    <th class="px-10 py-6">Date</th>
                    <th class="px-10 py-6">Description</th>
                    <th class="px-10 py-6 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                  <tr v-for="rec in incomeRecords" :key="rec.id" class="hover:bg-gray-50/50 transition-colors group">
                    <td class="px-10 py-6 text-gray-400 text-xs font-bold">{{ rec.date }}</td>
                    <td class="px-10 py-6 font-black text-gray-900 group-hover:text-gold transition-colors">{{ rec.description }}</td>
                    <td class="px-10 py-6 text-right font-black text-black text-lg">{{ toCurrency(rec.amount) }}</td>
                  </tr>
                  <tr v-if="incomeRecords.length === 0">
                    <td colspan="3" class="px-10 py-20 text-center">
                      <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <List class="w-8 h-8 text-gray-200" />
                      </div>
                      <p class="text-gray-400 font-bold">No income records found</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- EXPENSE TABLE -->
          <div class="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
            <div class="p-10 border-b border-gray-50 flex justify-between items-center bg-gray-50/30">
              <h3 class="text-xl font-black text-gray-900 tracking-tight">Expense History</h3>
              <span class="bg-black text-gold px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-black/20">{{ expenseRecords.length }} records</span>
            </div>
            <div class="overflow-x-auto">
              <table class="w-full text-left">
                <thead class="bg-gray-50/50 text-gray-400 text-[10px] font-black uppercase tracking-[0.2em]">
                  <tr>
                    <th class="px-10 py-6">Date</th>
                    <th class="px-10 py-6">Category</th>
                    <th class="px-10 py-6 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                  <tr v-for="rec in expenseRecords" :key="rec.id" class="hover:bg-gray-50/50 transition-colors group">
                    <td class="px-10 py-6 text-gray-400 text-xs font-bold">{{ rec.date }}</td>
                    <td class="px-10 py-6">
                      <p class="font-black text-gray-900 group-hover:text-gold transition-colors">{{ rec.category }}</p>
                      <p class="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">{{ rec.description }}</p>
                    </td>
                    <td class="px-10 py-6 text-right font-black text-black text-lg">{{ toCurrency(rec.amount) }}</td>
                  </tr>
                  <tr v-if="expenseRecords.length === 0">
                    <td colspan="3" class="px-10 py-20 text-center">
                      <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <List class="w-8 h-8 text-gray-200" />
                      </div>
                      <p class="text-gray-400 font-bold">No expense records found</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

:root {
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
}

/* Custom transitions */
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
}
</style>
